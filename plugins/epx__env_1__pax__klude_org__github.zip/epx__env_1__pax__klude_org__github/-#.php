<?php

class epx__env_1__pax__klude_org__github extends \stdClass implements \ArrayAccess, \JsonSerializable {
    
    public static function _() { static $i;  return $i ?: ($i = new static()); }
    
    public readonly array $_;
    
    private function __construct(){ 
        $this->_ = $_ENV;
        $_ENV = $this;
        function o(){ static $I; return $I ?? $I = \_::_(); }
    }
    
    public function __get($n){
        static $N =[];  return ($N[$k = \strtolower($n)] ?? ($N[$k] = \class_exists($c = "_\\{$k}") 
            ? $c::_()
            : (function($n){ 
                $GLOBALS['_TRACE'][] = "Node Not Found: '{$n}'";
                return false;
            })($n)
        )) ?: null;
    }    
    
    public function offsetSet($n, $v):void { 
        throw new \Exception('Set-Accessor is not supported for class '.static::class);
    }
    public function offsetExists($n):bool { 
        return isset($this->_[$n]);
    }
    public function offsetUnset($n):void { 
        throw new \Exception('Unset-Accessor is not supported for class '.static::class);
    }
    public function offsetGet($n):mixed { 
        if(!\array_key_exists($n, $this->_)){
            $k = "FW_{$n}";
            $this->_[$n] = 
                (\defined($k) ? \constant($k) : null)
                ?? ((($r = \getenv($k)) !== false) ? $r : null)
                ?? $_SERVER[$k]
                ?? $_SERVER["REDIRECT_{$k}"]
                ?? $_SERVER["REDIRECT_REDIRECT_{$k}"]
                ?? null
            ;
        }
        return $this->_[$n] ?? null;
    }
    
    public function jsonSerialize():mixed {
        return $this->_;
    }
    
    public function route(){
        if(\class_exists(\_\ui::class)){
            return \_\ui::_()->route();
        } else {
            return function(){ echo "Missing USER INTERFACE"; };
        }
    }
    
    public static function file(string $n, string $suffix = null){
        static $WRAPPER; $WRAPPER OR $WRAPPER = \class_exists(\_\i\file::class)
            ? \_\i\file::class
            : \SplFileInfo::class
        ;
        $p = \str_replace('\\','/', $n);
        if(($p[0]??'')=='/' || ($p[1]??'')==':'){
            $f = \realpath($GLOBALS['_TRACE']['Realpath Resolve'] = $p);
        } else {
            $f = (($suffix)
                ? \stream_resolve_include_path($GLOBALS['_TRACE']['File Resolve'] = "{$p}/{$suffix}") 
                    ?: (\stream_resolve_include_path($GLOBALS['_TRACE']['File Resolve'] = "{$p}{$suffix}")
                )
                : \stream_resolve_include_path($GLOBALS['_TRACE']['File Resolve'] = "{$p}")
            );
        }
        if($f){
            $GLOBALS['_TRACE']['File Found'] = $f = \str_replace('\\','/',$f);
            return new $WRAPPER($f);
        }
    }
    
    public static function glob($p, $flags = 0){
        static $WRAPPER; $WRAPPER OR $WRAPPER = \class_exists(\_\i\file::class)
            ? \_\i\file::class
            : \SplFileInfo::class
        ;
        if(\is_string($p)){
            /* using gxp would not work on files */
            $p = \_\p($p);
            $list = [];
            foreach(\explode(PATH_SEPARATOR, \get_include_path()) as $d){
                foreach(\glob("{$d}/{$p}", $flags) as $f){
                    $list[] = new $WRAPPER($f);
                }
            }
            return $list;
        } else {
            return [];
        }
    }
    
    public static function include(string|array $file, bool|callable $on_default = false):callable {
        if($__FILE__ = \is_string($file) ? static::file($file) : static::file(...$file)){
            return (function (array $__PARAM__) use($__FILE__){
                $__PARAM__ AND \extract($__PARAM__, EXTR_OVERWRITE | EXTR_PREFIX_ALL, 'p__');
                return include $__FILE__;
            })->bindTo(static::_(), static::class);
        } else {
            if(\is_callable($on_default) ){
                return $on_default;
            } else if($on_default == true){
                return function(){ };
            } else {
                if(\is_array($file)){
                    throw new \Exception("View not found: '{$file[0]}'");
                } else {
                    throw new \Exception("View not found: '{$file}'");
                }
            }
        }
    }
    
    public static function view(string $file, bool|callable $on_default = false):callable {
        if($__FILE__ = static::file($file,'-v.php')){
            return (function ($__INSET__ = null, array $__PARAM__ = null) use($__FILE__){
                if(\is_callable($__INSET__)){ 
                    $__INSET__ = \_\texate($__INSET__);
                } else if($__INSET__ instanceof \SplFileInfo) {
                    $__INSET__ = \_\texate(function() use($__INSET__){ include $__INSET__; });
                } else if(\is_array($__INSET__)) {
                    $__PARAM__ = $__INSET__;
                    $__INSET__ = $__PARAM__[0] ?? '';
                } else if(\is_scalar($__INSET__)) {
                    $__INSET__ = $__INSET__;
                }
                $__PARAM__ AND \extract($__PARAM__, EXTR_OVERWRITE | EXTR_PREFIX_ALL, 'p__');
                return include $__FILE__;
            })->bindTo(static::_(), static::class);
        } else {
            if(\is_callable($on_default) ){
                return $on_default;
            } else if($on_default == true){
                return function(){ };
            } else {
                throw new \Exception("View not found: '{$file}'");
            }
        }
    }

}