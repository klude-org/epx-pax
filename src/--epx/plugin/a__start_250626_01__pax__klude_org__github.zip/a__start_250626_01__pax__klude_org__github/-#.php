<?php

class a__start_250626_01__pax__klude_org__github {
    
    public static function _() { static $i;  return $i ?: ($i = new static()); }
    
    public function __invoke(){
        echo __METHOD__.":".__FILE__;
    }
    
}