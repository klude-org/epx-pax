<?php namespace epx__250627_01_neo_ui__pax__klude_org__github;

class cli extends \epx__250627_01_neo_ui__pax__klude_org__github {
    
    use \_\i\singleton__t;
    
    protected function __construct(){
        parent::__construct();
    }
    
    public function route(){
        return function(){
            
        };
    }    
    
}