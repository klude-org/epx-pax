<?php namespace epx__250706_01_ui__pax__klude_org__github\web\request;

class route extends \stdClass {
    
}
    
    

