<?php namespace epx__250706_01_ui__pax__klude_org__github\web;

class panel {

    use \_\i\instance__t;
    
}