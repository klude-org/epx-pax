<?php namespace epx__250706_01_ui__pax__klude_org__github;

class web extends \epx__250706_01_ui__pax__klude_org__github {
    
    use \_\i\instance__t;
    
    protected function __construct(){
        parent::__construct();
    }
    
}