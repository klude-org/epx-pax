<?php

class epx__250708_02_customer__pax__klude_org__github extends \_\env\com\db_model {
    use \_\i\singleton__t;
}