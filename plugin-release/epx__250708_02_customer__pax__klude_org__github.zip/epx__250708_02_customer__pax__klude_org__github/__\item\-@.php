<?php 

echo __FILE__.\_\BR;
\_\pre($this->record()); echo \_\BR;