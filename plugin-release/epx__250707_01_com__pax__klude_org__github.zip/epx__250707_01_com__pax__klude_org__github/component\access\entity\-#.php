<?php namespace epx__250707_01_com__pax__klude_org__github\component\access;

class entity {
    use __t;
}