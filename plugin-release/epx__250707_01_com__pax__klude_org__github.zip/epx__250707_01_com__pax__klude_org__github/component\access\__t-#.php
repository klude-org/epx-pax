<?php namespace epx__250707_01_com__pax__klude_org__github\component\access;

trait __t {
    
    use \_\i\instance__t;
    public readonly object $COM;
    protected function __construct($component){
        $this->COM = $component;
        $this->i__construct();
    }
    private function i__construct(){ }
    
}