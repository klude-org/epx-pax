<?php 

echo __FILE__.\_\BR;
echo '<pre>'; 
print_r($this);
