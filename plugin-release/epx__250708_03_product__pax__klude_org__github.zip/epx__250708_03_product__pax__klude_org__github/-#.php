<?php

class epx__250708_03_product__pax__klude_org__github extends \_\env\com\db_model {
    
}