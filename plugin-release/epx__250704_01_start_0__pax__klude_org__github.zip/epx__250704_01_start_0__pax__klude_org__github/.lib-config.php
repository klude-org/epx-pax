<?php 

1 AND $_["MODULES"][\epx__250626_01_abaca__pax__klude_org__github::class] = true;

1 AND $_[\_\db::class]['#'] = \epx__std_db__pax__klude_org__github::class;
0 AND $_[\_\db::class]['HOSTNAME'] = 'localhost';
1 AND $_[\_\db::class]['DATABASE'] = 'db-default';
0 AND $_[\_\db::class]['USERNAME'] = 'root';
0 AND $_[\_\db::class]['PASSWORD'] = '';

1 AND $_[\_\ui::class]['#'] = \epx__neo_ui__pax__klude_org__github::class;
0 AND $_[\_\composer::class]['#'] = \epx__neo_ui__pax__klude_org__github::class;
