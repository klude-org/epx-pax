<?php namespace _\env\com\panel;

class console {
    
    use \_\env\com\node__t;
    
}