<?php namespace _\env\com;

abstract class db_model {
    
    use component__t;
    
}