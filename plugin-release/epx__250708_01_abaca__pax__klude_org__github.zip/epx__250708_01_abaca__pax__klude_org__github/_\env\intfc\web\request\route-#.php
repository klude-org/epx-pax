<?php namespace _\env\intfc\web\request;

class route extends \stdClass {
    
}
    
    

