<?php namespace _\env\intfc\web;

class panel {

    use \_\i\instance__t;
    
}