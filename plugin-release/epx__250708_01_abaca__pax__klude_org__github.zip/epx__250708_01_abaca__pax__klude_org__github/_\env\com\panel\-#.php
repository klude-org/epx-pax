<?php namespace _\env\com;

abstract class panel {
    
    use component__t;
    
}