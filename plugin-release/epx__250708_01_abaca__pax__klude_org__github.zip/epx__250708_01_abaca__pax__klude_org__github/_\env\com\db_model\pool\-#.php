<?php namespace _\env\com\db_model\context;

class pool {
    use \_\env\com\context_node__t;
}