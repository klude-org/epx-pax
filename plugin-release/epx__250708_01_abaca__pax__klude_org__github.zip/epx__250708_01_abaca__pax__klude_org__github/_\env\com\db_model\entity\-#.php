<?php namespace _\env\com\db_model;

class entity {
    use \_\env\com\context_node__t;
}