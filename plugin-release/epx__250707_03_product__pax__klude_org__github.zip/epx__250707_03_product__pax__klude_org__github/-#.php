<?php

class epx__250707_03_product__pax__klude_org__github extends \_\i\component {
    use \_\i\singleton__t;
}